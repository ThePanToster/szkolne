wyniki = document.getElementById("wyniki")
document.getElementById("przycisk3").addEventListener("click", zolteTlo);
document.getElementById("przycisk4").addEventListener("click", bezTla);
document.getElementById("przycisk5").addEventListener("click", obramowanie);
document.getElementById("przycisk5").addEventListener("mouseover", zmienNapis);
document.getElementById("przycisk5").addEventListener("mouseout", przywrocNapis);
document.getElementById("wyniki").addEventListener("mouseover", powieksz);
document.getElementById("wyniki").addEventListener("mouseout", pomniejsz);

function zmienNapis() {
	this.style.fontWeight = "bold";
	this.style.color = "red";
}

function przywrocNapis() {
	this.style.fontWeight = "initial";
	this.style.color = "initial";
}

function czarnyTekst() {
	wyniki.style.color = "black";
}

function zolteTlo() {
	wyniki.style.backgroundColor = "yellow";
}

function bezTla() {
	wyniki.style.background = "none";
}

function powieksz() {
	wyniki.style.fontSize = "larger";
}

function pomniejsz() {
	wyniki.style.fontSize = "initial";
}

function kolorPrzycisk() {
	this.style.backgroundColor = "green";
}

function kolorPrzyciskReset() {
	this.style.backgroundColor = "lightgray";
}

function obramowanie() {
	wyniki.style.border = "2px dotted blue";
}