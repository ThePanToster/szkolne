bialy = document.getElementById("normal");
kontrast = document.getElementById("kontrast");
body = document.getElementsByTagName('body');
btn1 = document.getElementById("tab");
btn2 = document.getElementById("stat");
bialy.addEventListener('click', normalny);
bialy.addEventListener('mouseover', zaznacz);
bialy.addEventListener('mouseout', odznacz);
kontrast.addEventListener('click', kontrastowy);
kontrast.addEventListener('mouseover', zaznacz);
kontrast.addEventListener('mouseout', odznacz);
btn1.addEventListener('click', tablica);
btn2.addEventListener('click', statystyki);


function kontrastowy() {
    body[0].style.backgroundColor = "black";
	body[0].style.color = "white";
}
function normalny() {
    body[0].style.backgroundColor = "white";
	body[0].style.color = "black";
}

function zaznacz() {
    this.style.borderColor = "red";	
	this.style.cursor = "pointer";
}

function odznacz() {
    this.style.borderColor = "black";	
	this.style.cursor = "default";
}

function tablica(){
    btn2.style.visibility = "visible";	
	tekst = "Tablica 5x7<br>";
	tablica = [5];
	for (i = 0; i < 5; i++)
		for (j = 0; j < 7; j++)
			tablica[i] = [7];
	for (i = 0; i < 5; i++) {
		for (j = 0; j < 7; j++) {
            tablica[i][j] = Math.floor(Math.random() * 10 + 10);
			tekst += tablica[i][j] + " ";
		}
	    tekst += "<br>";
	}
	document.getElementById("tablica").innerHTML = tekst;
	
}

function statystyki() {
	tekst = "Średnia elementów wynosi ";
	suma = 0;
	for (i = 0; i < 5; i++)
		for (j = 0; j < 7; j++)
		    suma += tablica[i][j];
	tekst += (suma/35).toFixed(2);
	document.getElementById("statystyki").innerHTML = tekst;
        btn2.style.visibility = "hidden";	
}