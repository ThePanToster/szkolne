          function definiuj() {
		     var n = 20;
			 tab = [];
			 for (i = 0; i < n; i++)
			    tab[i] = Math.floor(Math.random() * 99 + 1);
		  }
		  
		  function wyswietl() {
		     tekst = "";
			 for (i = 0; i < tab.length; i++)
			     tekst += tab[i] + " ";
			 tekst += "<span> (" + tab.length + ") </span>";
			 document.getElementById("wyniki").innerHTML = tekst;
		  }
		  
	      function reset() {
		     definiuj();
		     wyswietl();
		  }
		  
		  function dodajKoniec() {
		     tab.push(Math.floor(Math.random() * 99 + 1));   //push - dodanie na końcu tablicy
			 wyswietl();
		  }
		  
		  function usunKoniec() {
		     tab.pop();                                      //pop - usuniecie ostatniego elementu tablicy
			 wyswietl();
		  }
		  
		  function dodajPoczatek() {
		     tab.unshift(Math.floor(Math.random() * 99 + 1));  //unshift - dodanie na początek tablicy
			 wyswietl();
		  }
		  
		  function usunPoczatek() {
		     tab.shift();                                      //shift - usuniecie pierwszego elementu tablicy
			 wyswietl();
		  }
		  
		  function usun3() {
		     tab.splice(tab.length-3, 3);                      //splice - usuniecie elementów tablicy
			 wyswietl();
		  }
		  
		  function usunX() {
		     pozycja = Number(prompt("Od którego kolejnego elementu usunąć?"));
			 ile = Number(prompt("Ile elementów usunąć?"));
		     tab.splice(pozycja-1, ile);                      
			 wyswietl();
		  }
		  
		  function wstaw() {
		     liczba = Number(prompt("Jaką liczbę wstawić?"));
			 pozycja = Number(prompt("W które miejsce wstawić " + liczba + "?"));
			 tab.splice(pozycja-1, 0, liczba);                //splice - wstawienie elementu na określoną pozycję (bez usuwania)
			 wyswietl();
		  }
		  
		  function zamien() {
		     liczba = Number(prompt("Jaką liczbę wstawić?"));
			 pozycja = Number(prompt("Podaj miejsce zamienianej liczby?"));
			 tab.splice(pozycja-1, 1, liczba);                //splice - zamiana elementu tablicy
			 wyswietl();
		  }
		  
		  function sortuj() {     //przerwa do 12:22
		     //tab.sort();                   //sortowanie tekstowe
		     tab.sort((a, b) => a - b);      //sortowanie liczbowe rosnąco
			 //tab.sort((a, b) => b - a);    //sortowanie liczbowe malejąco
			 wyswietl();
		  }
	      
		  function odwroc() {
		      tab.reverse();
			  wyswietl();
		  }
		  
		  function zamienLiczbe() {
		     liczbaDoZamiany = Number(prompt("Podaj liczbe do zmiany?"));
			 liczba = Number(prompt("Nowa wartość:"));
			 pozycja = -1;
			 for (i = 0; i < tab.length; i++) {
			    pozycja = tab.indexOf(liczbaDoZamiany, pozycja+1);
			    //console.log(pozycja);
			    tab.splice(pozycja, 1, liczba);                //splice - zamiana elementu tablicy
			 }
			 wyswietl();
		  }