
div = document.getElementsByTagName("div");
for (var i = 1; i < div.length; i++)
  if (i != 4 && i != 8) {
	//div[i].addEventListener("click", przycisk);
	div[i].addEventListener("mousedown", przycisk);
	//div[i].addEventListener("mouseup", zeruj);
	div[i].addEventListener("dblclick", zeruj);
	div[i].addEventListener("mouseover", zaznacz);
	div[i].addEventListener("mouseout", odznacz);
  }

function przycisk() {
    if (event.button == 0)
	   this.style.backgroundColor = "lightgreen";
	if (event.button == 1)
	   this.style.backgroundColor = "lightblue";  
	
}

function zeruj() {
	     this.style.background = "lightgray";    
}

function zaznacz() {
	     this.style.border = "2px solid pink";    
}

function odznacz() {
	     this.style.borderColor = "white";    
}
