/*
1) [2 PKT] Po naciśnięciu przycisku TABLICA pojawia się monit o wprowadzenie ilości wierszy (n)
   oraz ilości kolumn (m), a następnie w elmencie DIV wyświetla się tablica NxM z losowymi elementami od <0;9>
2) [1 PKT] Po naciśnięciu przycisku STATYSTYKI pod tablicą wyświetla się ilość zer w tablicy   
   oraz średnia elementów parzystych
3) [1 PKT] Po najechaniu kursorem myszy na DIV'a tekst w jego wnętrzu staje się pogrubiony
   (font-weight: bold), a po usunięciu kursora myszy wraca do trybu normalnego (normal)
4) [1 PKT] Po naciśnięciu przycisku WYGLĄD zmienia się styl przycisków TABLICA i STATYSTYKI:
   - przycisk TABLICA (tło: olive, obramowanie 5px, kropkowane, ciemnozielone)
   - przycisk STATYSTYKI (tło: żółte, obramowanie 5px, kropkowane, pomarańczowe)

*/

btn1 = document.getElementById("tab");
btn2 = document.getElementById("stat");
btn3 = document.getElementById("wyglad");
wyniki = document.getElementById("tablica");

btn1.addEventListener('click', tablica);
btn2.addEventListener('click', statystyki);
btn3.addEventListener('click', ustaw);
wyniki.addEventListener('mouseover', zaznacz);
wyniki.addEventListener('mouseout', odznacz);

function ustaw() {
    btn1.style.background = "olive";
    btn1.style.border = "5px dotted darkgreen";		
	btn2.style.background = "yellow";
    btn2.style.border = "5px dotted orange";		
}

function zaznacz() {
    this.style.fontWeight = "bold";	
	this.style.cursor = "pointer";
}

function odznacz() {
    this.style.fontWeight = "normal";		
	this.style.cursor = "default";
}

function tablica(){
	n = Number(prompt("Ilość wierszy:"));
	m = Number(prompt("Ilość kolumn:"));
	tekst = "Tablica " + n + "x" + m + "<br>";
	tablica = [n];
	for (i = 0; i < n; i++)
		for (j = 0; j < m; j++)
			tablica[i] = [m];
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
            tablica[i][j] = Math.floor(Math.random() * 10);
			tekst += tablica[i][j] + " ";
		}
	    tekst += "<br>";
	}
	wyniki.innerHTML = tekst;
}

function statystyki () {
	licznik = 0;
	liczParz = 0;
	suma = 0;
	for (i = 0; i < n; i++)
		for (j = 0; j < m; j++) {
			if (tablica[i][j] == 0)
				licznik++;
			if (tablica[i][j] % 2 == 0) {
				suma += tablica[i][j]
                liczParz++;
			}
		}
	tekst = "<br>Ilość zer: " + licznik + "<br>";
    tekst += "Średnia elementów parzystych: " + (suma/liczParz).toFixed(2);
    wyniki.innerHTML +=	tekst;
}
